#ifndef LICENCES_H_INCLUDED
#define LICENCES_H_INCLUDED

// license macros
#define LICENSE_GPL _("This program is licensed under the terms\nof the GNU General Public License version 3\r\n\n" \
  "Available online under:\nhttp://www.gnu.org/licenses/gpl-3.0.html")	/// url's adress

#define LICENSE_WXWINDOWS _("This program is distributed under the wxWindows Library License version 3\n\n" \
  "http://www.wxwidgets.org/about/licence3.txt")  // c'est un commentaire



#endif // LICENCES_H_INCLUDED
/* an add comment  */
