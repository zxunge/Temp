/// cbp\Readme.txt  (UTF8)

/// LETARTARE

Here you will find one project 'Code::Blocks' to build 'wxrc.exe'.

	'wxcr_gcc_2.9.cbp' use 'TDM-4.7.1' (or gcc-4.7.1) and 'wxWidgets-2.9.4' or '2.9.5'

You must place
	'wxrc_gcc_2.9.cbp' in your directory '$(#wx29)\utils\wxrc'
	to use the correct version of 'wxrc'.

Each project has four targets unicode :
	- 'Release win32'		: poly, statique, release  (recommended as independent)
	- 'Debug win 2' 		: poly, statique, debug
	- 'Dll Release win32'	: mono, dynamique, release
	- 'Dll Debug win 32' 	: mono, dynamique, debug

Load project and use the target you need.

You will need to copy 'wxrc.exe' in the directory 'Poedit' or '$(#cb_exe)'
