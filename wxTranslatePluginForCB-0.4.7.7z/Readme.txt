Readme.txt  (UTF8)

LETARTARE(http://forums.codeblocks.org)

v 0.4.7 : April 08, 2015 (for Win32)

//------------------------------------------------------------------------------
1 - What is this project:
//------------------------------------------------------------------------------

	The goal is to translate, in the local language, the development projects
	under 'Code::Blocks', only those using 'wxWidgets'.

	The extension script 'script\wxTranslate_plugin.script' to generate in
	directory 'trlocale' a file :
		- 'name_projet.po' for a single project,
		- or 'name_projet_workspace.po' for cooperative project (workspace).

	This file is provided to 'Poedit', built-in 'Code::Blocks', which generates
	file '*.mo', to put in the executable directory for test

//------------------------------------------------------------------------------
2- Prerequisites
//------------------------------------------------------------------------------

	1- 'xgettex.exe' and 'msmerge.exe' must be installed in the system path
		(system variable PATH), or either with 'codeblocks.exe'

		-> 'Poedit' contient 'xgettext.exe' et 'msmerge.exe'
			'http://www.poedit.net/'
		To install 'Poedit' in 'Code::Blocks' :
			1- read 'http://wiki.codeblocks.org/index.php?title=Configure_tools',
			2- read 'infos/wxTranslate_exp.en' paragraph 'SETUP 'Poedit',

	2- 'wxrc.exe' must be installed (see 'wxrc\cbp\Alire.txt),
		- either with 'xgettext.exe'
		- either with 'codeblocks.exe'
		- either in the directory  'path-wx-2.9.x\utils\wxrc'

		-> wxWidgets-2-9.x at 'http://www.wxwidgets.org/'

//------------------------------------------------------------------------------
3- Installation in 'Code::Blocks' (without 'Poedit') :
//------------------------------------------------------------------------------

	1- install 'wxTranslatepluginforCB-x.y.z' in any directory

	2- in 'Code::Blocks' by the 'Settings->Scripting...->General-> Add' menu
		- load 'script\wxTranslate_plugin.script' and check 'Enabled'
		- in the 'Security' tab check all

	3- Restartto use the script.

//------------------------------------------------------------------------------
4 - Fast Start in 'Code::Blocks' (without 'Poedit') :
//------------------------------------------------------------------------------

	context menu = right click on an VIRTUAL directory in the Project Manager
	projects

	1- load project 'wxTranslatePluginForCB-x.y.z' in 'Code::Blocks',

	2- open the script console 'View->Script console',

	3- activate project 'wxTranslatePluginForCB-x.y.z',

	4- activate context menu on an VIRTUAL directory in the active project manager
		projects and select :

			'wxTranslate->List ...',

		which lists the files with strings,

	5- after activate context menu on an virtual directory in the active project :

			'wxTranslate->Extract ... '

		which extracts the strings and creates the file

			'trlocale\name_projet.po'

	6- item 'wxTranslate->Clean ...' eliminates, if necessary, potential
		temporary files	created during listing.

//------------------------------------------------------------------------------
5 - Detailed use
//------------------------------------------------------------------------------

	The directory 'infos' files contains the explanatory use.
